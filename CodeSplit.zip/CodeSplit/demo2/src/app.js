import { sum } from "./math";

console.log("hello app");
console.log(sum(1, 2, 3, 4));

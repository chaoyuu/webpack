import { sum } from "./math";

console.log("hello main");
console.log(sum(1, 2, 3));

class CleanWebpackPlugin {
   apply(compiler) {

      //获取打包输出的目录
      const outputPath = compiler.options.output.path;
      const fs = compiler.outputFileSystem;
      // console.log(outputPath);

      //注册钩子，在打包输出之前emit
      compiler.hooks.emit.tap("CleanWebpackPlugin", (compilation) => {


         //通过fs删除打包输出的目录下的所有文件
         this.removeFiles(fs, outputPath)

      });
   }

   removeFiles(fs, filepath) {

      //读取当前目录下所有资源
      const files = fs.readdirSync(filepath)
      console.log(files);//[ 'images', 'index.html', 'js' ]
      //2.遍历一个个删除
      files.forEach(file => {
         const path = `${filepath}/${file}`;
         const fileStat = fs.statSync(path);
         // console.log(fileStat);
         //文件夹删除
         if (fileStat.isDirectory()) {
            this.removeFiles(fs, path);

         } else {
            fs.unlinkSync(path);

         }
      })

   }
}

module.exports = CleanWebpackPlugin;

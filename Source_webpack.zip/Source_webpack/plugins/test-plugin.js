class TestPlugin {

    constructor() {
        console.log("TestPlugin constructor");
    }
    apply(complier) {

        debugger;
        console.log("complier", complier);
        console.log("testPlugin apply");


        //同步钩子
        complier.hooks.environment.tap('TestPlugin', () => {
            console.log("TestPlugin enviroment");
        });

        complier.hooks.emit.tap('TestPlugin', (compliation) => {
            console.log('compliation', compliation);
            console.log("TestPlugin emit 111");


        });

        complier.hooks.emit.tapAsync('TestPlugin', (compliation, callback) => {

            setTimeout(() => {
                console.log("TestPlugin emit 222");
                callback();
            }, 2000);


        });


        complier.hooks.emit.tapPromise('TestPlugin', (compliation) => {

            return new Promise((resolve) => {

                setTimeout(() => {
                    console.log("TestPlugin emit 333");
                    resolve();
                }, 1000);
            });



        });
        complier.hooks.make.tapAsync('TestPlugin', (compliation, callback) => {

            //需要compliation触发前才能使用
            compliation.hooks.seal.tap('TestPlugin', () => {
                console.log("TestPlugin seal");
            });
            setTimeout(() => {
                console.log("TestPlugin make 111");
                callback();
            }, 3000);

        });

        complier.hooks.make.tapAsync('TestPlugin', (compliation, callback) => {

            setTimeout(() => {
                console.log("TestPlugin make 222");
                callback();
            }, 1000);

        });

        complier.hooks.make.tapAsync('TestPlugin', (compliation, callback) => {

            setTimeout(() => {
                console.log("TestPlugin make 333");
                callback();
            }, 2000);

        });
    }
}

module.exports = TestPlugin;

/* 
webpack加载webpack.config.js中所有配置
*/
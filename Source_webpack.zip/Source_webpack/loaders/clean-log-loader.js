module.exports = function (content) {
    //清楚文件内容中consloe.log
    return content.replace(/console\.log\(.*\);?/g, '');
}